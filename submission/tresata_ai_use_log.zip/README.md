# AI-use log for the finance assignment

This archive documents how the prototype and submission materials were developed.

Integrity note: this is a curated AI-assisted development record from the available conversation and repository evidence, not a verbatim export of every chat turn. Exact user wording is preserved only where available; reconstructed summaries are labeled as such.

The archive contains no private financial data. The prototype uses synthetic suppliers, purchase orders, receipts, credits, and invoices.

Files:

- `conversation_reconstruction.md` — user questions, AI-assisted work, and the resulting decisions.
- `architecture_and_edge_cases.md` — the critical design questions and the edge cases deliberately tested.
- `execution_and_local_deployment.md` — implementation, testing, and local run evidence.
- `evidence_index.md` — repository files supporting the claims in this log.

If an actual platform conversation export is available, attach it separately as the verbatim record. Do not invent missing turns.
